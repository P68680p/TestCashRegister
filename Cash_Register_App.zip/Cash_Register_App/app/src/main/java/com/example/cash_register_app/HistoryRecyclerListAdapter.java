package com.example.cash_register_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class HistoryRecyclerListAdapter extends RecyclerView.Adapter<HistoryRecyclerListAdapter.HistoryListViewHolder> {

    public HistoryRecyclerListAdapter(){};
    ArrayList<HistoryItem> list ;
    Context context;

//    public HistoryRecyclerListAdapter(ArrayList<HistoryItem> list, Context context) {
//        this.list = list;
//        this.context = context;
//    }

    class HistoryListViewHolder extends RecyclerView.ViewHolder {
        TextView nameProd;
        TextView amount;
        TextView totalPrice;

        public HistoryListViewHolder(@NonNull View itemView) {
            super(itemView);
            nameProd = itemView.findViewById(R.id.rec_row_prod_name);
            amount = itemView.findViewById(R.id.rec_row_quantity);
            totalPrice = itemView.findViewById(R.id.rec_row_total_price);
        }
    }
    public HistoryRecyclerListAdapter(ArrayList<HistoryItem> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public HistoryListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.list_recycle_adapter_row,parent,false);
        return new HistoryListViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryListViewHolder holder, int position) {

        holder.nameProd.setText("hell");
        holder.amount.setText("12");
        holder.totalPrice.setText("456");
//        holder.nameProd.setText(list.get(position).getDescription());
//        holder.amount.setText(list.get(position).getQuantity());
//        holder.totalPrice.setText((int) list.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }


//    class HistoryListViewHolder extends RecyclerView.ViewHolder {
//        TextView nameProd;
//        TextView amount;
//        TextView totalPrice;
//
//        public HistoryListViewHolder(@NonNull View itemView) {
//            super(itemView);
//            nameProd = itemView.findViewById(R.id.rec_row_prod_name);
//            amount = itemView.findViewById(R.id.rec_row_quantity);
//            totalPrice = itemView.findViewById(R.id.rec_row_total_price);
//        }
//    }
}
