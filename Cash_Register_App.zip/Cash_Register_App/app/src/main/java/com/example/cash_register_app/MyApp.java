package com.example.cash_register_app;

import android.app.Application;

public class MyApp extends Application {

    InventoryItem item = new InventoryItem();
    Store storeObject = new Store();

}
