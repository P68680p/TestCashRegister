package com.example.cash_register_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

public class HistoryRecyclerList extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_recycler_list);
        Log.d("Cash Register App", "HistoryRecyclerList Created");
        this.setTitle("History List");

        recyclerView = findViewById(R.id.historyRecyclerList);
        HistoryRecyclerListAdapter h = new HistoryRecyclerListAdapter();

        HistoryRecyclerListAdapter adapter = new HistoryRecyclerListAdapter(h.list, this);
        //HistoryRecyclerListAdapter adapter = new HistoryRecyclerListAdapter(((MyApp) getApplication()).storeObject.getHistory(), this);
        //adapter.listener = this;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

//        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        System.out.println("-------------> arrayList history" + ((MyApp) getApplication()).storeObject.getHistory());
    }
}